Project source and scratch files are stored here.

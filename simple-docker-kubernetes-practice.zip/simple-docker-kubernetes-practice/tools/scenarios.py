"""Practice guide scenarios. Each line in a phase is ONE terminal command."""
import textwrap

SCENARIOS = []

def add(sid, title, see, brk, find, fix, check, say, env='Local lab', note=''):
    def lines(s):
        return [x.strip() for x in textwrap.dedent(s).strip().splitlines() if x.strip()]
    SCENARIOS.append(dict(id=sid,title=title,see=see,breaks=lines(brk),finds=lines(find),fixes=lines(fix),checks=lines(check),say=say,env=env,note=note))

# ------- Docker (10) -------
GOOD='docker run -d --name practice-web --label practice.simple.lab=yes -p 127.0.0.1:18080:8080 practice-web:1'
DCHK='curl -fsS http://127.0.0.1:18080/healthz'
add('DCK-001','Container stops after starting','STATUS=Exited; exit code 1.', '''
 docker rm -f practice-web
 docker run -d --name practice-web --label practice.simple.lab=yes practice-web:1 python -c 'import sys;sys.exit(1)'
''','''
 docker ps -a
 docker inspect practice-web --format '{{.State.ExitCode}}'
 docker logs practice-web
''',f'''docker rm -f practice-web
{GOOD}''',f'''docker ps
{DCHK}''','Check exit code, examine logs, then start the container with its correct application command.')
add('DCK-002','Container keeps restarting','STATUS=Restarting repeatedly after a real process crash.', '''
 docker rm -f practice-web
 docker run -d --restart always --name practice-web --label practice.simple.lab=yes -e APP_MODE=crash practice-web:1
''','''
 docker ps -a
 docker inspect practice-web --format '{{.RestartCount}}'
 docker logs practice-web
''',f'''docker rm -f practice-web
{GOOD}''',f'''docker ps
{DCHK}''','A restart policy does not fix a crashing process; logs reveal the root cause.')
add('DCK-003','Container running but website unreachable','Container is Up, but curl fails because host port goes to the wrong container port.', '''
 docker rm -f practice-web
 docker run -d --name practice-web --label practice.simple.lab=yes -p 127.0.0.1:18080:8081 practice-web:1
''','''
 docker ps
 docker port practice-web
 docker inspect practice-web --format '{{json .NetworkSettings.Ports}}'
 curl -v --max-time 3 http://127.0.0.1:18080/
''',f'''docker rm -f practice-web
{GOOD}''',f'''docker port practice-web
{DCHK}''','Check the port binding and application listening port, not just whether the process is Up.')
add('DCK-004','Wrong environment variable crashes the app','APP_PORT=wrong is not an integer; application exits.', '''
 docker rm -f practice-web
 docker run -d --name practice-web --label practice.simple.lab=yes -e APP_PORT=wrong practice-web:1
''','''
 docker ps -a
 docker logs practice-web
 docker inspect practice-web --format '{{json .Config.Env}}'
''',f'''docker rm -f practice-web
{GOOD}''',f'''docker logs practice-web
{DCHK}''','Read the configuration error before changing the environment variable.')
add('DCK-005','Docker health check is unhealthy','The process runs, but the configured /healthz returns 503.', '''
 docker rm -f practice-web
 docker run -d --name practice-web --label practice.simple.lab=yes -e APP_MODE=unhealthy --health-cmd='wget -q -O /dev/null http://127.0.0.1:8080/healthz' --health-interval=5s --health-retries=2 practice-web:1
''','''
 docker ps
 docker inspect practice-web --format '{{json .State.Health}}'
 docker logs practice-web
''',f'''docker rm -f practice-web
{GOOD}''',f'''docker ps
{DCHK}''','Up means running; Healthy means the configured health check succeeds.', note='Wait about 15 seconds for Docker health status to change. The repaired baseline runs without a Docker HEALTHCHECK; its HTTP health endpoint is checked explicitly.')
add('DCK-006','Read-only filesystem prevents writes','Application exits with a read-only filesystem or permission error.', '''
 docker rm -f practice-web
 docker run -d --name practice-web --label practice.simple.lab=yes --read-only -e APP_MODE=write practice-web:1
''','''
 docker ps -a
 docker logs practice-web
 docker inspect practice-web --format '{{.HostConfig.ReadonlyRootfs}}'
''','''
 docker rm -f practice-web
 docker run -d --name practice-web --label practice.simple.lab=yes --read-only --mount type=volume,source=practice-data-6,target=/data -e APP_MODE=write -p 127.0.0.1:18080:8080 practice-web:1
''',f'''docker ps
{DCHK}
curl -fsS http://127.0.0.1:18080/value''','Read-only root filesystems need explicit writable mounts for data.')
add('DCK-007','Two containers cannot resolve each other','Client loses the practice-net attachment, so Docker DNS cannot resolve practice-web.', '''
 docker network disconnect practice-net practice-client
''','''
 docker network inspect practice-net
 docker inspect practice-client --format '{{json .NetworkSettings.Networks}}'
 docker exec practice-client python -c 'import socket;print(socket.gethostbyname("practice-web"))'
''','''
 docker network connect practice-net practice-client
''','''
 docker network inspect practice-net
 docker exec practice-client python -c 'import urllib.request;print(urllib.request.urlopen("http://practice-web:8080/healthz").status)'
''','Compare network membership. Container names resolve only on appropriate user-defined networks.')
add('DCK-008','Container is OOMKilled','OOMKilled=true and often exit code 137 after exceeding its enforced memory cgroup.', '''
 docker rm -f practice-web
 docker run -d --name practice-web --label practice.simple.lab=yes --memory=48m -e APP_MODE=allocate -e ALLOC_MB=256 practice-web:1
''','''
 docker ps -a
 docker inspect practice-web --format '{{.State.OOMKilled}} {{.State.ExitCode}}'
 docker logs practice-web
''',f'''docker rm -f practice-web
{GOOD}''',f'''docker ps
{DCHK}''','Separate container memory limit kills from a general node or VM memory shortage.', note='Requires Docker memory cgroup enforcement. Memory allocation behavior may vary by OS and runtime.')
add('DCK-009','Image missing: container cannot be created','Docker reports the image is not present; no container is created.', '''
 docker rm -f practice-web
 docker run --pull=never --name practice-web practice-web:does-not-exist
''','''
 docker images
 docker ps -a
 docker image inspect practice-web:does-not-exist
''',f'''docker image inspect practice-web:1
{GOOD}''',f'''docker ps
{DCHK}''','Check the exact repository and tag; distinguish pull/registry errors from application crashes.', note='The break command is expected to fail; continue with the next command.')
add('DCK-010','Bind mount source path does not exist','Docker refuses to start because --mount requires an existing host path.', '''
 docker rm -f practice-web
 docker run --name practice-web --label practice.simple.lab=yes --mount type=bind,source="$PWD/scratch/this-path-does-not-exist",target=/data practice-web:1
''','''
 docker ps -a
 ls -ld scratch
 docker volume ls
''','''
 mkdir -p scratch/data-10
 docker run -d --name practice-web --label practice.simple.lab=yes --mount type=bind,source="$PWD/scratch/data-10",target=/data -p 127.0.0.1:18080:8080 practice-web:1
''',f'''docker inspect practice-web --format '{{json .Mounts}}'
{DCHK}''','Check whether the bind source exists and whether the container has permission to mount it.', note='The broken docker run returns an error immediately. If scratch/this-path-does-not-exist already exists, remove that practice-only folder before rerunning.')

# ------- Kubernetes (50) -------
K='kubectl -n practice'
PODS=f'{K} get pods -o wide'
DESCRIBE=f'{K} describe pods -l app=web'
LOGS=f'{K} logs deployment/web --tail=30'
EVENTS=f'{K} get events --sort-by=.metadata.creationTimestamp'
OK=f'{K} rollout status deployment/web --timeout=120s'
KHTTP='kubectl -n practice exec deployment/web -- python -c \'import urllib.request;print(urllib.request.urlopen("http://web/healthz").status)\''

add('K8S-001','Pod stuck Pending','Pod Pending, warning FailedScheduling; no node has label lab=missing.', '''
 kubectl -n practice patch deployment web -p '{"spec":{"template":{"spec":{"nodeSelector":{"lab":"missing"}}}}}'
''',f'''{PODS}
{DESCRIBE}
kubectl get nodes --show-labels''','''
 kubectl -n practice patch deployment web -p '{"spec":{"template":{"spec":{"nodeSelector":null}}}}'
''',f'''{OK}
{PODS}''','Pending with FailedScheduling points to scheduling constraints, not application logs.')
add('K8S-002','CrashLoopBackOff','Restart count grows because the web application exits with an error.', '''
 kubectl -n practice set env deployment/web APP_MODE=crash
''',f'''{PODS}
{DESCRIBE}
kubectl -n practice logs deployment/web --previous''','''
 kubectl -n practice set env deployment/web APP_MODE=normal
''',f'''{OK}
{PODS}''','Use --previous to read logs from the crashed container.')
add('K8S-003','ImagePullBackOff','A nonexistent image tag causes Failed to pull and then ImagePullBackOff.', '''
 kubectl -n practice set image deployment/web web=practice-web:missing
''',f'''{PODS}
{DESCRIBE}
{EVENTS}''','''
 kubectl -n practice set image deployment/web web=practice-web:1
''',f'''{OK}
{PODS}''','Check image name, registry access and pull events before restarting Pods.')
add('K8S-004','ErrImagePull','Initial pull failure from a deliberately invalid registry; may turn into ImagePullBackOff.', '''
 kubectl -n practice set image deployment/web web=invalid.example.invalid/practice-web:v1
''',f'''{PODS}
{DESCRIBE}
{EVENTS}''','''
 kubectl -n practice set image deployment/web web=practice-web:1
''',f'''{OK}
{PODS}''','ErrImagePull and ImagePullBackOff describe stages of the same image retrieval failure.')
add('K8S-005','Pod stuck ContainerCreating','A required Secret volume does not exist; events show FailedMount.', '''
 kubectl -n practice patch deployment web --type=strategic -p '{"spec":{"template":{"spec":{"volumes":[{"name":"bad-secret","secret":{"secretName":"missing-secret"}}],"containers":[{"name":"web","volumeMounts":[{"name":"bad-secret","mountPath":"/missing"}]}]}}}}'
''',f'''{PODS}
{DESCRIBE}
{EVENTS}''','''
 kubectl -n practice create secret generic missing-secret --from-literal=token=dummy
''',f'''{OK}
{PODS}''','Read FailedMount events; image pulling is not the only reason for ContainerCreating.')
add('K8S-006','Pod Running, HTTP application returns errors','Pod is Ready but main URL gives 500: Kubernetes status is not an application test.', '''
 kubectl -n practice set env deployment/web APP_MODE=fail-http
''',f'''{PODS}
{LOGS}
kubectl -n practice exec deployment/web -- python -c 'import urllib.request;urllib.request.urlopen("http://127.0.0.1:8080/")' ''','''
 kubectl -n practice set env deployment/web APP_MODE=normal
''',f'''{OK}
kubectl -n practice exec deployment/web -- python -c 'import urllib.request;print(urllib.request.urlopen("http://127.0.0.1:8080/").status)' ''','An HTTP failure can occur while probes and Pod conditions look healthy.')
add('K8S-007','Pod Running but not Ready','Readiness endpoint returns 503; Pod is Running with READY 0/1.', '''
 kubectl -n practice set env deployment/web APP_MODE=unready
''',f'''{PODS}
{DESCRIBE}
{EVENTS}''','''
 kubectl -n practice set env deployment/web APP_MODE=normal
''',f'''{OK}
{PODS}''','Readiness controls whether the Pod is included in Service endpoints.')
add('K8S-008','Pod restarting repeatedly','Process exits every 5 seconds, causing an increasing restart count.', '''
 kubectl -n practice set env deployment/web APP_MODE=crash-after
''',f'''{PODS}
kubectl -n practice logs deployment/web --previous
{DESCRIBE}''','''
 kubectl -n practice set env deployment/web APP_MODE=normal
''',f'''{OK}
{PODS}''','Check restart count, last termination reason and previous logs.')
add('K8S-009','Container OOMKilled','The app allocates more than its 128Mi memory limit and is killed.', '''
 kubectl -n practice set env deployment/web APP_MODE=allocate ALLOC_MB=200
''',f'''{PODS}
{DESCRIBE}
kubectl -n practice get pods -l app=web -o jsonpath='{{.items[0].status.containerStatuses[0].lastState.terminated.reason}}' ''','''
 kubectl -n practice set env deployment/web APP_MODE=normal ALLOC_MB-
''',f'''{OK}
{PODS}''','OOMKilled is a reason for a terminated container; investigate limits and memory usage.', note='Workload allocation may vary across runtimes. This deliberately breaches the Pod container memory limit, not host memory.')
add('K8S-010','Pod stuck Terminating','A 90-second preStop hook delays termination.', '''
 kubectl -n practice patch deployment web --type=strategic -p '{"spec":{"template":{"spec":{"terminationGracePeriodSeconds":120,"containers":[{"name":"web","lifecycle":{"preStop":{"exec":{"command":["sh","-c","sleep 90"]}}}}]}}}}'
 kubectl -n practice rollout status deployment/web --timeout=120s
 kubectl -n practice delete pod "$(kubectl -n practice get pod -l app=web -o jsonpath='{.items[0].metadata.name}')" --wait=false
''',f'''{PODS}
{DESCRIBE}
{EVENTS}''','''
 kubectl -n practice patch deployment web --type=json -p='[{"op":"remove","path":"/spec/template/spec/containers/0/lifecycle"}]'
''',f'''{OK}
{PODS}''','Check lifecycle hooks and grace periods; wait for this isolated Pod to finish naturally.', note='The old Pod may remain Terminating for up to the grace period. Do not force-delete production Pods merely because they are slow.')
add('K8S-011','Application exits immediately with code 0','A Deployment restarts even a container that exits successfully.', '''
 kubectl -n practice set env deployment/web APP_MODE=exit0
''',f'''{PODS}
{DESCRIBE}
kubectl -n practice logs deployment/web --previous''','''
 kubectl -n practice set env deployment/web APP_MODE=normal
''',f'''{OK}
{PODS}''','Deployments need long-running processes; one-shot work is usually a Job.')
add('K8S-012','Pod logs show invalid application configuration','APP_PORT is not numeric; Python terminates with ValueError.', '''
 kubectl -n practice set env deployment/web APP_PORT=wrong
''',f'''{PODS}
kubectl -n practice logs deployment/web --previous
{DESCRIBE}''','''
 kubectl -n practice set env deployment/web APP_PORT=8080
''',f'''{OK}
{PODS}''','Logs can identify misconfiguration faster than repeated restarts.')
add('K8S-013','Service exists but application unreachable','Service targetPort is wrong; Pod endpoint listens on 8080.', '''
 kubectl -n practice patch service web -p '{"spec":{"ports":[{"port":80,"targetPort":9999}]}}'
''',f'''{K} get service web
{K} get endpointslices -l kubernetes.io/service-name=web
{KHTTP}''','''
 kubectl -n practice patch service web -p '{"spec":{"ports":[{"port":80,"targetPort":8080}]}}'
''',f'''{KHTTP}
{K} get service web''','Compare Service targetPort to the container listening port.')
add('K8S-014','Service selector does not match Pod labels','Service has zero backend endpoints.', '''
 kubectl -n practice patch service web -p '{"spec":{"selector":{"app":"wrong"}}}'
''',f'''{K} get pods --show-labels
{K} get service web -o yaml
{K} get endpointslices -l kubernetes.io/service-name=web''','''
 kubectl -n practice patch service web -p '{"spec":{"selector":{"app":"web"}}}'
''',f'''{K} get endpointslices -l kubernetes.io/service-name=web
{KHTTP}''','Service selectors must match the labels on healthy Pods.')
add('K8S-015','ClusterIP reachable but server listens only on loopback','The app binds to 127.0.0.1, not its Pod IP; Service requests fail.', '''
 kubectl -n practice set env deployment/web APP_BIND=127.0.0.1
''',f'''{PODS}
{LOGS}
{DESCRIBE}''','''
 kubectl -n practice set env deployment/web APP_BIND=0.0.0.0
''',f'''{OK}
{KHTTP}''','Check both Service routing and the address the application binds to.')
add('K8S-016','NodePort returns connection refused','NodePort exists but maps to a nonexistent backend container port.', '''
 kubectl -n practice expose deployment web --name=web-node --type=NodePort --port=80 --target-port=8080
 kubectl -n practice patch service web-node -p '{"spec":{"ports":[{"port":80,"targetPort":9999}]}}'
''',f'''{K} get service web-node
{K} describe service web-node
{K} get endpointslices -l kubernetes.io/service-name=web-node''','''
 kubectl -n practice patch service web-node -p '{"spec":{"ports":[{"port":80,"targetPort":8080}]}}'
''',f'''{K} get service web-node
{K} exec deployment/web -- python -c 'import urllib.request;print(urllib.request.urlopen("http://web-node/healthz").status)' ''','A NodePort may not be reachable directly from a Mac/Windows host without a Kind port mapping; investigate the in-cluster path first.', note='NodePort itself is inside the Docker node network. Verify the Service from inside the cluster; host-level NodePort access requires an explicit Kind mapping.')
add('K8S-017','Ingress HTTP 404','Ingress host is wrong, so Traefik has no matching route.', '''
 kubectl -n practice apply -f manifests/ingress-bad-host.yaml
''',f'''{K} get ingress
{K} describe ingress web-ingress
{K} exec deployment/web -- python -c 'import urllib.request;u=urllib.request.Request("http://traefik.traefik.svc.cluster.local",headers={{"Host":"practice.test"}});print(urllib.request.urlopen(u).status)' ''','''
 kubectl -n practice apply -f manifests/ingress.yaml
''',f'''{K} get ingress
{K} exec deployment/web -- python -c 'import urllib.request;u=urllib.request.Request("http://traefik.traefik.svc.cluster.local",headers={{"Host":"practice.test"}});print(urllib.request.urlopen(u).status)' ''','An HTTP 404 at the ingress controller often means no route matched the host/path.',env='Local Kind + optional Traefik', note='Before prepare: install Helm and run ./lab addon ingress. This scenario changes a real Ingress object; controller image and chart are external dependencies.')
add('K8S-018','Ingress HTTP 502/503','Route matches but refers to a nonexistent Service.', '''
 kubectl -n practice apply -f manifests/ingress-bad-backend.yaml
''',f'''{K} describe ingress web-ingress
{K} get services
{K} get endpointslices
{K} exec deployment/web -- python -c 'import urllib.request;u=urllib.request.Request("http://traefik.traefik.svc.cluster.local",headers={{"Host":"practice.test"}});urllib.request.urlopen(u)' ''','''
 kubectl -n practice apply -f manifests/ingress.yaml
''',f'''{K} exec deployment/web -- python -c 'import urllib.request;u=urllib.request.Request("http://traefik.traefik.svc.cluster.local",headers={{"Host":"practice.test"}});print(urllib.request.urlopen(u).status)' ''','Check that the Ingress points to a Service that exists and has ready endpoints.',env='Local Kind + optional Traefik', note='Depending on controller version, a missing backend can return HTTP 502, 503 or another error status. The failure must be observed, not assumed.')
add('K8S-019','DNS resolution fails inside a Pod','The Pod uses a deliberately invalid DNS server address.', '''
 kubectl -n practice patch deployment web --type=merge -p '{"spec":{"template":{"spec":{"dnsPolicy":"None","dnsConfig":{"nameservers":["203.0.113.53"]}}}}}'
''',f'''{PODS}
{K} exec deployment/web -- cat /etc/resolv.conf
{K} exec deployment/web -- python -c 'import socket;print(socket.gethostbyname("kubernetes.default.svc.cluster.local"))' ''','''
 kubectl -n practice patch deployment web --type=merge -p '{"spec":{"template":{"spec":{"dnsPolicy":"ClusterFirst","dnsConfig":null}}}}'
''',f'''{OK}
{K} exec deployment/web -- python -c 'import socket;print(socket.gethostbyname("kubernetes.default.svc.cluster.local"))' ''','Check /etc/resolv.conf before assuming CoreDNS itself is broken.')
add('K8S-020','Pods cannot reach backend Pod','The backend binds only to localhost; frontend cannot connect to the backend Service.', '''
 kubectl -n practice set env deployment/backend APP_BIND=127.0.0.1
''',f'''{K} get pods -o wide
{K} logs deployment/backend --tail=20
{K} exec deployment/web -- python -c 'import urllib.request;urllib.request.urlopen("http://backend/healthz",timeout=3)' ''','''
 kubectl -n practice set env deployment/backend APP_BIND=0.0.0.0
''',f'''{K} rollout status deployment/backend --timeout=120s
{K} exec deployment/web -- python -c 'import urllib.request;print(urllib.request.urlopen("http://backend/healthz").status)' ''','Test connection from the client Pod and compare Service endpoints to the backend bind address.')
add('K8S-021','Readiness probe uses the wrong URL','readinessProbe checks /wrong instead of /readyz; Pod is Running, not Ready.', '''
 kubectl -n practice patch deployment web --type=strategic -p '{"spec":{"template":{"spec":{"containers":[{"name":"web","readinessProbe":{"httpGet":{"path":"/wrong","port":8080}}}]}}}}'
''',f'''{PODS}
{DESCRIBE}
{EVENTS}''','''
 kubectl -n practice patch deployment web --type=strategic -p '{"spec":{"template":{"spec":{"containers":[{"name":"web","readinessProbe":{"httpGet":{"path":"/readyz","port":8080}}}]}}}}'
''',f'''{OK}
{PODS}''','A readiness failure removes endpoints without necessarily restarting the container.')
add('K8S-022','Liveness probe repeatedly restarts a healthy app','Wrong liveness URL causes the kubelet to kill the container.', '''
 kubectl -n practice patch deployment web --type=strategic -p '{"spec":{"template":{"spec":{"containers":[{"name":"web","livenessProbe":{"httpGet":{"path":"/wrong","port":8080}}}]}}}}'
''',f'''{PODS}
{DESCRIBE}
{EVENTS}''','''
 kubectl -n practice patch deployment web --type=strategic -p '{"spec":{"template":{"spec":{"containers":[{"name":"web","livenessProbe":{"httpGet":{"path":"/healthz","port":8080}}}]}}}}'
''',f'''{OK}
{PODS}''','Differentiate a process crash from a kubelet-initiated restart after liveness failures.', note='Wait 15–30 seconds to see repeated liveness failures and restarts.')
add('K8S-023','Application cannot contact its API dependency','The frontend points to an invalid backend DNS name and returns HTTP 502.', '''
 kubectl -n practice set env deployment/web EXTERNAL_URL=http://backend-does-not-exist/healthz
''',f'''{K} get services
{K} logs deployment/web --tail=25
{K} exec deployment/web -- python -c 'import urllib.request;urllib.request.urlopen("http://127.0.0.1:8080/external")' ''','''
 kubectl -n practice set env deployment/web EXTERNAL_URL=http://backend/healthz
''',f'''{OK}
{K} exec deployment/web -- python -c 'import urllib.request;print(urllib.request.urlopen("http://127.0.0.1:8080/external").status)' ''','Verify the actual dependency URL, DNS and HTTP response before changing cluster networking.', note='The backend Service acts as a safe stand-in for an external API. Public internet egress and firewall behavior are different tests.')
add('K8S-024','NetworkPolicy blocks good traffic','Calico-enforced deny ingress policy blocks frontend-to-backend HTTP.', '''
 kubectl -n practice apply -f manifests/networkpolicy-deny.yaml
''',f'''{K} get networkpolicy
{K} describe networkpolicy deny-web
{K} get pods --show-labels
{K} exec deployment/web -- python -c 'import urllib.request;urllib.request.urlopen("http://web/healthz",timeout=3)' ''','''
 kubectl -n practice delete networkpolicy deny-web
''',f'''{K} get networkpolicy
{KHTTP}''','NetworkPolicy is enforced by the CNI, not by the Kubernetes API object itself.',env='Separate Kind/VM cluster with Calico', note='Create a tester Deployment first (kubectl -n practice create deployment tester --image=practice-web:1). NOT EXECUTABLE on the default Kind kindnet CNI. Follow official Calico-on-Kind setup in a SEPARATE disposable cluster, build/load the app there, and deploy manifests/base.yaml in namespace practice. The local ./lab prepare intentionally refuses this ID rather than pretending a policy was enforced.')
add('K8S-025','Worker node NotReady','The named worker is stopped as a Docker container; after a delay Kubernetes marks it NotReady.', '''
 docker stop interview-lab-worker
''','''
 kubectl get nodes -o wide
 kubectl describe node interview-lab-worker
 kubectl get pods -A -o wide
''','''
 docker start interview-lab-worker
''','''
 kubectl wait --for=condition=Ready node/interview-lab-worker --timeout=180s
 kubectl get nodes
''','Distinguish a node failure from a single application Pod failure.',note='Use ONLY the named disposable Kind worker. This can take 40–120 seconds to show NotReady. Web may remain available if it runs on the other worker.')
add('K8S-026','Pod cannot schedule: insufficient CPU','A Pod that requests 10 CPU cores exceeds the Kind worker node capacity.', '''
 kubectl -n practice set resources deployment web --requests=cpu=10 --limits=cpu=10
''',f'''{PODS}
{DESCRIBE}
kubectl describe nodes''','''
 kubectl -n practice set resources deployment web --requests=cpu=20m --limits=cpu=200m
''',f'''{OK}
{PODS}''','FailedScheduling and node Allocatable values reveal oversized CPU requests.')
add('K8S-027','Pod cannot schedule: insufficient memory','A 100Gi memory request cannot fit in the disposable Kind workers.', '''
 kubectl -n practice set resources deployment web --requests=memory=100Gi --limits=memory=100Gi
''',f'''{PODS}
{DESCRIBE}
kubectl describe nodes''','''
 kubectl -n practice set resources deployment web --requests=memory=32Mi --limits=memory=128Mi
''',f'''{OK}
{PODS}''','Requests influence scheduling; limits influence runtime enforcement.')
add('K8S-028','Node taint blocks Pod scheduling','All worker nodes have NoSchedule taint; a new Pod remains Pending.', '''
 kubectl taint nodes interview-lab-worker interview=blocked:NoSchedule
 kubectl taint nodes interview-lab-worker2 interview=blocked:NoSchedule
 kubectl -n practice rollout restart deployment/web
''',f'''{PODS}
{DESCRIBE}
kubectl describe nodes''','''
 kubectl taint nodes interview-lab-worker interview:NoSchedule-
 kubectl taint nodes interview-lab-worker2 interview:NoSchedule-
''',f'''{OK}
{PODS}''','NoSchedule is checked for new Pods. Existing Pods are not evicted by that taint alone.',note='Changes ONLY the two disposable Kind workers. ./lab reset also removes these specific lab taints.')
add('K8S-029','Required node affinity matches no worker','A required node affinity rule asks for a label no Kind node has.', '''
 kubectl -n practice patch deployment web --type=merge -p '{"spec":{"template":{"spec":{"affinity":{"nodeAffinity":{"requiredDuringSchedulingIgnoredDuringExecution":{"nodeSelectorTerms":[{"matchExpressions":[{"key":"lab","operator":"In","values":["no-such-node"]}]}]}}}}}}}'
''',f'''{PODS}
{DESCRIBE}
kubectl get nodes --show-labels''','''
 kubectl -n practice patch deployment web --type=merge -p '{"spec":{"template":{"spec":{"affinity":null}}}}'
''',f'''{OK}
{PODS}''','Required affinity blocks scheduling when no node matches.')
add('K8S-030','PVC stuck Pending','PVC refers to a StorageClass that does not exist.', '''
 kubectl -n practice apply -f manifests/pvc-bad.yaml
''','''
 kubectl -n practice get pvc
 kubectl -n practice describe pvc broken-data
 kubectl get storageclass
''','''
 kubectl -n practice delete pvc broken-data
 kubectl -n practice apply -f manifests/pvc-good.yaml
 kubectl -n practice apply -f manifests/consumer.yaml
''','''
 kubectl -n practice get pvc
 kubectl -n practice wait --for=condition=Ready pod/volume-check --timeout=150s
''','Check StorageClass, volume binding mode and provisioner events.',note='Kind typically installs a default local-path StorageClass; check kubectl get storageclass first. A WaitForFirstConsumer claim may remain Pending until a Pod uses it.')
add('K8S-031','Pod cannot mount the requested PVC','storage-app refers to an absent PVC and stays Pending with FailedMount.', '''
 kubectl -n practice patch deployment storage-app --type=strategic -p '{"spec":{"template":{"spec":{"volumes":[{"name":"data","persistentVolumeClaim":{"claimName":"does-not-exist"}}]}}}}'
''','''
 kubectl -n practice get pods
 kubectl -n practice describe deployment storage-app
 kubectl -n practice describe pods -l app=storage-app
 kubectl -n practice get pvc
''','''
 kubectl -n practice patch deployment storage-app --type=strategic -p '{"spec":{"template":{"spec":{"volumes":[{"name":"data","persistentVolumeClaim":{"claimName":"lab-data"}}]}}}}'
''','''
 kubectl -n practice rollout status deployment/storage-app --timeout=150s
 kubectl -n practice get pvc
''','Compare Pod claimName to existing PVCs, then inspect Pod mount events.',note='Requires Kind local-path provisioning; ./lab prepare checks that a good PVC-mounted Pod starts.')
add('K8S-032','Container cannot write to persistent volume','A read-only volumeMount breaks the web app that writes to /data at startup.', '''
 kubectl -n practice patch deployment storage-app --type=strategic -p '{"spec":{"template":{"spec":{"containers":[{"name":"storage-app","volumeMounts":[{"name":"data","mountPath":"/data","readOnly":true}]}]}}}}'
''','''
 kubectl -n practice get pods
 kubectl -n practice logs deployment/storage-app --previous
 kubectl -n practice describe pods -l app=storage-app
''','''
 kubectl -n practice patch deployment storage-app --type=strategic -p '{"spec":{"template":{"spec":{"containers":[{"name":"storage-app","volumeMounts":[{"name":"data","mountPath":"/data","readOnly":false}]}]}}}}'
''','''
 kubectl -n practice rollout status deployment/storage-app --timeout=150s
 kubectl -n practice exec deployment/storage-app -- cat /data/ready.txt
''','Check mount readOnly flag and filesystem permissions instead of assuming the volume is absent.')
add('K8S-033','Deployment rolling update cannot complete','New ReplicaSet uses an unavailable image; old Pod often stays Ready.', '''
 kubectl -n practice set image deployment/web web=practice-web:broken-release
''',f'''{K} get deployments
{K} get replicasets
{PODS}
{K} describe deployment web''','''
 kubectl -n practice set image deployment/web web=practice-web:1
''',f'''{OK}
{K} get replicasets''','Check rollout status and new ReplicaSet rather than deleting the old healthy Pods.')
add('K8S-034','Bad release needs rollback','An unhealthy new revision cannot become Ready.', '''
 kubectl -n practice set env deployment/web APP_MODE=unready
''',f'''{PODS}
{K} rollout history deployment/web
{DESCRIBE}''','''
 kubectl -n practice rollout undo deployment/web
''',f'''{OK}
{PODS}
{K} rollout history deployment/web''','Rollback to the last known-good ReplicaSet when recovery is faster and safer than a hot fix.')
add('K8S-035','HPA does not scale because it cannot read metrics','HPA reports unknown CPU utilization until metrics-server is installed.', '''
 kubectl -n practice autoscale deployment web --cpu=50% --min=1 --max=3
''','''
 kubectl -n practice get hpa
 kubectl -n practice describe hpa web
 kubectl top pods -n practice
''','''
 ./lab addon metrics
''','''
 kubectl top pods -n practice
 kubectl -n practice get hpa
''','HPA requires the metrics API and a meaningful CPU request; scaling also requires sustained load.',env='Local Kind + optional Metrics Server',note='Run BEFORE installing the metrics addon if you want to observe missing metrics. With the addon installed, the failure will no longer occur. A healthy HPA with metrics does NOT automatically scale unless there is sufficient load.')
add('K8S-036','PodDisruptionBudget blocks a node drain','One web replica with minAvailable=1 cannot be evicted voluntarily.', '''
 kubectl drain interview-lab-worker --ignore-daemonsets --delete-emptydir-data --timeout=20s
''','''
 kubectl get nodes
 kubectl -n practice get poddisruptionbudgets
 kubectl -n practice describe poddisruptionbudget web-pdb
 kubectl -n practice get pods -o wide
''','''
 kubectl -n practice delete poddisruptionbudget web-pdb
 kubectl uncordon interview-lab-worker
''','''
 kubectl get nodes
 kubectl -n practice get pods
''','PDB is a voluntary disruption safety control. Plan additional capacity before a real production drain.',note='The drain is EXPECTED to time out and leave the worker cordoned. ./lab reset uncordons this worker.')
add('K8S-037','StatefulSet Pod fails to start','StatefulSet database-0 crashes because APP_PORT is not numeric.', '''
 kubectl -n practice set env statefulset/database APP_PORT=wrong
''','''
 kubectl -n practice get statefulsets
 kubectl -n practice get pods
 kubectl -n practice logs database-0 --previous
''','''
 kubectl -n practice set env statefulset/database APP_PORT=8080
''','''
 kubectl -n practice rollout status statefulset/database --timeout=120s
 kubectl -n practice get pods
''','StatefulSet Pod names are stable; inspect database-0 and the StatefulSet update.',note='This isolates StatefulSet process recovery; it does not require a real SQL server.')
add('K8S-038','ConfigMap change is not reflected','Environment variables in an existing container remain unchanged after ConfigMap edit.', '''
 kubectl -n practice patch configmap lab-config -p '{"data":{"APP_MESSAGE":"NEW VALUE"}}'
''','''
 kubectl -n practice get configmap lab-config -o yaml
 kubectl -n practice exec deployment/web -- printenv APP_MESSAGE
 kubectl -n practice get pods
''','''
 kubectl -n practice rollout restart deployment/web
''',f'''{OK}
{K} exec deployment/web -- printenv APP_MESSAGE''','ConfigMap changes do not automatically refresh env vars in existing containers.')
add('K8S-039','Secret key is missing: CreateContainerConfigError','Pod requires missing key from lab-secret; it cannot create the container.', '''
 kubectl -n practice patch deployment web --type=strategic -p '{"spec":{"template":{"spec":{"containers":[{"name":"web","env":[{"name":"API_KEY","valueFrom":{"secretKeyRef":{"name":"lab-secret","key":"missing"}}}]}]}}}}'
''',f'''{PODS}
{DESCRIBE}
{K} get secret lab-secret''','''
 kubectl -n practice patch secret lab-secret -p '{"data":{"missing":"ZHVtbXk="}}'
''',f'''{OK}
{K} exec deployment/web -- printenv API_KEY''','The Pod event names the missing Secret/key; fix the key rather than repeatedly deleting Pods.',note='All values are dummy practice credentials. Do not paste real secrets into shell history.')
add('K8S-040','Kubernetes Job fails','Job exits 7 and becomes Failed after retries.', '''
 kubectl -n practice apply -f manifests/secret-bad-job.yaml
''','''
 kubectl -n practice get jobs
 kubectl -n practice get pods
 kubectl -n practice logs job/broken-job
 kubectl -n practice describe job broken-job
''','''
 kubectl -n practice delete job broken-job
 kubectl -n practice apply -f manifests/job-good.yaml
''','''
 kubectl -n practice wait --for=condition=complete job/recovered-job --timeout=120s
 kubectl -n practice logs job/recovered-job
''','Check exit code, Job backoffLimit and completed/failed counts. Jobs are for finite tasks.')
add('K8S-041','Intermittent frontend timeouts','The app becomes slow when APP_MODE=slow; a 2-second client timeout fails.', '''
 kubectl -n practice set env deployment/web APP_MODE=slow
''',f'''{OK}
{K} exec deployment/web -- python -c 'import urllib.request;urllib.request.urlopen("http://web/slow",timeout=2)' 
{LOGS}''','''
 kubectl -n practice set env deployment/web APP_MODE=normal
''',f'''{OK}
{K} exec deployment/web -- python -c 'import urllib.request;print(urllib.request.urlopen("http://web/slow",timeout=2).status)' ''','Separate app response time from DNS resolution, connection setup and Pod health.',note='Real microservice timeouts can also involve network saturation and dependencies; this lab demonstrates a genuine timeout with one simple app.')
add('K8S-042','Node DiskPressure causes evictions','Observe DiskPressure=True and Evicted only on a disposable VM with a dedicated test filesystem.', '''
 # No safe one-line disk-fill injection is provided for a shared Mac/Windows Docker disk.
''','''
 kubectl get nodes
 kubectl describe nodes
 kubectl get pods -A --field-selector=status.phase=Failed
 kubectl get events -A --sort-by=.metadata.creationTimestamp
''','''
 # On a dedicated VM: remove only your test fill file, restore free space, and restart the affected workload if required.
''','''
 kubectl get nodes
 kubectl get pods -A
''','Confirm actual node pressure and filesystem usage; avoid deleting random data or blindly restarting Pods.',env='Dedicated disposable Ubuntu/VM only',note='NOT a supported automatic failure on local Kind: filling the host disk can damage other work. For a real experiment, use a dedicated VM/test disk with a size limit and a documented snapshot rollback. These are diagnosis prompts, NOT a falsely claimed executed failure.')
add('K8S-043','Memory pressure causes application instability','Several over-limit app containers enter OOMKilled/restart states; this is a safe proxy, NOT genuine Node MemoryPressure.', '''
 kubectl -n practice scale deployment/web --replicas=3
 kubectl -n practice set env deployment/web APP_MODE=allocate ALLOC_MB=200
''',f'''{PODS}
{DESCRIBE}
kubectl top nodes''','''
 kubectl -n practice set env deployment/web APP_MODE=normal ALLOC_MB-
 kubectl -n practice scale deployment/web --replicas=1
''',f'''{OK}
{PODS}''','Check container OOM, node MemoryPressure condition and resource requests separately.',note='This experiment creates real container OOMs. It does not reliably push the node into MemoryPressure; that requires a separate disposable VM and careful capacity controls.')
add('K8S-044','Service has no healthy EndpointSlices','A failing readiness check removes the Pod from ready Service endpoints.', '''
 kubectl -n practice set env deployment/web APP_MODE=unready
''',f'''{PODS}
{K} get endpointslices -l kubernetes.io/service-name=web -o yaml
{DESCRIBE}''','''
 kubectl -n practice set env deployment/web APP_MODE=normal
''',f'''{OK}
{K} get endpointslices -l kubernetes.io/service-name=web''','A Service object existing does not guarantee it has ready backends.')
add('K8S-045','Kubernetes API server is unreachable','Pausing only the disposable Kind control-plane container stops API responses.', '''
 docker pause interview-lab-control-plane
''','''
 kubectl --request-timeout=5s get nodes
 docker ps -a --filter name=interview-lab-control-plane
 docker inspect interview-lab-control-plane --format '{{.State.Paused}}'
''','''
 docker unpause interview-lab-control-plane
''','''
 kubectl --request-timeout=20s get nodes
 kubectl -n practice get pods
''','If kubectl cannot connect, check kubeconfig, API endpoint and the control-plane process first.',note='Only on named disposable Kind control plane; commands targeting the API will fail while it is paused. ./lab reset recovers the paused container.')
add('K8S-046','kubelet on a worker stops responding','The real kubelet service inside a disposable Kind worker is stopped.', '''
 docker exec interview-lab-worker systemctl stop kubelet
''','''
 docker exec interview-lab-worker systemctl is-active kubelet
 kubectl get nodes
 kubectl describe node interview-lab-worker
''','''
 docker exec interview-lab-worker systemctl start kubelet
''','''
 docker exec interview-lab-worker systemctl is-active kubelet
 kubectl wait --for=condition=Ready node/interview-lab-worker --timeout=180s
''','kubelet failure is a node-agent problem, not necessarily a control-plane outage.',note='Requires a Kind node image with systemd/kubelet service. If the command is unsupported, run this scenario on a dedicated Ubuntu kubeadm VM instead; do not claim it happened.')
add('K8S-047','CoreDNS failure breaks name resolution','Scaling CoreDNS to zero stops new cluster DNS responses.', '''
 kubectl -n kube-system scale deployment/coredns --replicas=0
''','''
 kubectl -n kube-system get deployments
 kubectl -n kube-system get pods -l k8s-app=kube-dns
 kubectl -n practice exec deployment/web -- python -c 'import socket;print(socket.gethostbyname("kubernetes.default.svc.cluster.local"))'
''','''
 kubectl -n kube-system scale deployment/coredns --replicas=2
''','''
 kubectl -n kube-system rollout status deployment/coredns --timeout=150s
 kubectl -n practice exec deployment/web -- python -c 'import socket;print(socket.gethostbyname("kubernetes.default.svc.cluster.local"))'
''','Investigate DNS deployment health before changing application Services.',note='This changes a CORE cluster component, but ONLY in the disposable named Kind cluster. ./lab reset restores CoreDNS replicas to 2.')
add('K8S-048','TLS trust / Kubernetes kubeconfig error','A COPIED kubeconfig uses the wrong CA, producing an x509 trust error.', '''
 kubectl config view --raw > scratch/trust-broken.yaml
 kubectl --kubeconfig scratch/trust-broken.yaml config unset clusters.kind-interview-lab.certificate-authority-data
 kubectl --kubeconfig scratch/trust-broken.yaml config set-cluster kind-interview-lab --certificate-authority="$PWD/manifests/not-the-real-ca.pem" --embed-certs
 kubectl --kubeconfig scratch/trust-broken.yaml get nodes
''','''
 kubectl --kubeconfig scratch/trust-broken.yaml config view --minify
 kubectl --kubeconfig scratch/trust-broken.yaml get nodes
 kubectl --context kind-interview-lab get nodes
''','''
 rm -f scratch/trust-broken.yaml
''','''
 kubectl --context kind-interview-lab get nodes
''','Keep the real kubeconfig untouched and compare its CA trust with the broken copy.',note='This reproduces a REAL client TLS trust mismatch, not actual certificate expiration. Requires curl etc? No; the public wrong-CA PEM is included in manifests/.')
add('K8S-049','RBAC Forbidden for a ServiceAccount','An unprivileged practice ServiceAccount cannot list Pods.', '''
 kubectl --as=system:serviceaccount:practice:reader -n practice get pods
''','''
 kubectl auth can-i list pods --as=system:serviceaccount:practice:reader -n practice
 kubectl -n practice get serviceaccount reader
 kubectl -n practice get rolebindings
''','''
 kubectl -n practice create role pod-reader --verb=get,list,watch --resource=pods
 kubectl -n practice create rolebinding pod-reader-binding --role=pod-reader --serviceaccount=practice:reader
''','''
 kubectl auth can-i list pods --as=system:serviceaccount:practice:reader -n practice
 kubectl --as=system:serviceaccount:practice:reader -n practice get pods
''','Use kubectl auth can-i, then grant the smallest necessary namespaced Role.',note='The initial kubectl get is EXPECTED to show Forbidden; this lab does not require any real cloud IAM permissions.')
add('K8S-050','Three cascading failures: backend, Service and frontend','Backend crashes, its Service selector is wrong, and frontend points at a missing dependency.', '''
 kubectl -n practice set env deployment/backend APP_MODE=crash
 kubectl -n practice patch service backend -p '{"spec":{"selector":{"app":"wrong"}}}'
 kubectl -n practice set env deployment/web EXTERNAL_URL=http://missing-backend/healthz
''','''
 kubectl -n practice get pods -o wide
 kubectl -n practice get services
 kubectl -n practice get endpointslices
 kubectl -n practice logs deployment/backend --previous
 kubectl -n practice exec deployment/web -- python -c 'import urllib.request;urllib.request.urlopen("http://127.0.0.1:8080/external")'
''','''
 kubectl -n practice set env deployment/backend APP_MODE=normal
 kubectl -n practice patch service backend -p '{"spec":{"selector":{"app":"backend"}}}'
 kubectl -n practice set env deployment/web EXTERNAL_URL=http://backend/healthz
''','''
 kubectl -n practice rollout status deployment/backend --timeout=120s
 kubectl -n practice rollout status deployment/web --timeout=120s
 kubectl -n practice exec deployment/web -- python -c 'import urllib.request;print(urllib.request.urlopen("http://127.0.0.1:8080/external").status)'
''','Start at the user-visible symptom, trace frontend-to-backend, fix each proven fault and verify the full traffic path.')

assert len(SCENARIOS)==60, (len(SCENARIOS), [x['id'] for x in SCENARIOS])
assert len(set(x['id'] for x in SCENARIOS))==60

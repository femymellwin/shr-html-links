#!/usr/bin/env python3
"""Build one extremely simple, printable HTML practice document and a plain text copy."""
import html
import json
from pathlib import Path
from scenarios import SCENARIOS

ROOT=Path(__file__).resolve().parent.parent
H=html.escape

def cmd_list(lines):
    out=[]
    for i,cmd in enumerate(lines,1):
        if cmd.startswith('#'):
            out.append(f'<p class="notice">{H(cmd[1:].strip())}</p>')
        else:
            out.append(f'<div class="command"><span class="stepnum">{i}.</span><code>{H(cmd)}</code></div>')
    return ''.join(out)

sections=[]
for i,s in enumerate(SCENARIOS):
    k8=s['id'].startswith('K8S')
    local = s['id'] not in ('K8S-024','K8S-042')
    preparation=([f"./lab prepare {s['id']}", 'kubectl -n practice get pods'] if k8 else [f"./lab prepare {s['id']}", ('docker network inspect practice-net' if s['id']=='DCK-007' else 'curl -fsS http://127.0.0.1:18080/healthz')])
    if not local:
        preparation=[]
    note=(f'<p class="note"><strong>Important:</strong> {H(s["note"])}</p>' if s['note'] else '')
    if k8 and s['id']=='K8S-024':
        prep='<p class="note">Extra setup is required: create a <strong>separate Calico-enabled Kind cluster</strong> using the official Calico guide. The default kindnet plugin does not enforce NetworkPolicy. Once a fresh namespace and the two example Deployments (web and tester) are present, the commands below become a practice checklist. Do not run this against a production cluster.</p>'
    elif k8 and s['id']=='K8S-042':
        prep='<p class="note">This question is <strong>VM-only diagnosis practice</strong>, not a promised local failure. Real node DiskPressure involves node filesystem capacity and is not safe to induce by filling your laptop disk. Study the commands below and practise on a completely disposable test VM with a separately limited disk.</p>'
    else:
        prep=cmd_list(preparation)
    group = 'Docker' if not k8 else 'Kubernetes'
    sections.append(f'''<article class="scenario" id="{s['id']}">
        <h3>Question {i+1 if not k8 else i-9}. {H(s['title'])} <span class="sid">{H(s['id'])}</span></h3>
        <p><strong>Interviewer:</strong> "{H(s['title'])}. How would you investigate and recover?"</p>
        <p class="env">Where: {H(s['env'])}</p>
        <h4>1. Start healthy</h4>{prep}
        <h4>2. Break it — type each command</h4>{cmd_list(s['breaks'])}
        <p class="expect"><strong>What should go wrong:</strong> {H(s['see'])}</p>
        <h4>3. Find the problem — type these in order</h4>{cmd_list(s['finds'])}
        <h4>4. Fix it — type each command</h4>{cmd_list(s['fixes'])}
        <h4>5. Check recovery</h4>{cmd_list(s['checks'])}
        <p class="remember"><strong>Say in the interview:</strong> {H(s['say'])}</p>
        {note}
    </article>''')

before=''.join(sections[:10]); after=''.join(sections[10:])
start=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Simple Docker & Kubernetes: Break, Find, Fix</title>
<style>
:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#fff;color:#202632;font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif}
main{max-width:930px;margin:0 auto;padding:30px 24px 70px}h1{font-size:31px;line-height:1.2;margin:0 0 8px}h2{font-size:25px;margin:42px 0 15px;border-bottom:2px solid #dedfe5;padding-bottom:8px}h3{font-size:21px;line-height:1.3;margin:0 0 12px}h4{font-size:16px;margin:21px 0 8px}p{margin:11px 0}a{color:#215f88}.subtitle{font-size:18px;color:#445064}.scenario{border-top:1px solid #d8dee6;padding:27px 0 29px;break-inside:avoid}.sid{font-size:13px;font-weight:600;color:#576b82;white-space:nowrap}.env{font-size:14px;color:#4d5565}.command{display:flex;gap:12px;align-items:flex-start;margin:6px 0;break-inside:avoid}.stepnum{font-weight:700;color:#495768;min-width:18px;padding-top:8px;font-size:13px}code{display:block;background:#f6f7f9;color:#1f2e3a;border:1px solid #e3e6eb;border-radius:5px;padding:8px 10px;overflow-wrap:anywhere;white-space:pre-wrap;word-break:break-word;font:13.3px/1.47 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;flex:1}.expect{margin-top:11px}.note{border-left:3px solid #8b94a6;padding:8px 12px;background:#fafafa;font-size:14px;color:#384352}.notice{font-size:14px;color:#725125}.remember{font-size:14.5px}.small{font-size:14px;color:#566171}.intro{border-bottom:1px solid #ddd;padding-bottom:18px}.setup{padding:2px 0 10px}p code,li code{display:inline;padding:1px 4px;font-size:13px;white-space:normal;word-break:normal}.quick{font-weight:600}ul{padding-left:23px}li{margin:6px 0}hr{border:0;border-top:2px solid #dedfe5;margin:30px 0} @media print{body{font-size:11pt}main{padding:0;max-width:none}.scenario{break-inside:auto}code{font-size:8pt;page-break-inside:avoid}h3,h4{break-after:avoid}a{color:#000;text-decoration:none}}
</style></head><body><main>
<div class="intro"><h1>Simple Docker & Kubernetes Troubleshooting Practice</h1>
<p class="subtitle">60 interview questions. Type one command at a time. No dashboards or complex navigation.</p>
<p><strong>Every question follows the same five steps:</strong> Start healthy → Break it → Find the cause → Fix it → Check recovery.</p>
<p class="small">Scope: 10 Docker + 50 Kubernetes exercises. Most use one disposable Kind cluster. Optional Ingress, metrics, NetworkPolicy and actual node DiskPressure have clearly stated prerequisites or limitations. No commands were live-tested against Docker in the document-generation environment.</p></div>
<section class="setup"><h2>Part 1. Install only once</h2>
<p>Choose <strong>one</strong> of these computers. After installation, everyone runs <strong>the same commands</strong> in a Bash terminal.</p>
<h3>A. Mac laptop</h3>
<p>Install <a href="https://docs.docker.com/desktop/setup/install/mac-install/">Docker Desktop for Mac</a> and start it. Install Homebrew from <a href="https://brew.sh/">brew.sh</a> if needed. Open Terminal and type:</p>
<div class="command"><span class="stepnum">1.</span><code>brew install kind kubectl</code></div>
<div class="command"><span class="stepnum">2.</span><code>docker version</code></div>
<div class="command"><span class="stepnum">3.</span><code>kind version</code></div>
<div class="command"><span class="stepnum">4.</span><code>kubectl version --client</code></div>
<h3>B. Windows laptop</h3>
<p>Open <strong>PowerShell as Administrator</strong>, type the next command, then restart if prompted:</p>
<div class="command"><span class="stepnum">1.</span><code>wsl --install -d Ubuntu</code></div>
<p>Install <a href="https://docs.docker.com/desktop/setup/install/windows-install/">Docker Desktop for Windows</a>; enable its <strong>WSL 2 backend</strong> and <strong>Settings → Resources → WSL Integration → Ubuntu</strong>. Use Linux containers, not Windows containers. Open the <strong>Ubuntu (WSL)</strong> terminal, NOT PowerShell, for all subsequent practice commands.</p>
<div class="command"><span class="stepnum">2.</span><code>sudo apt update</code></div>
<div class="command"><span class="stepnum">3.</span><code>sudo apt install -y curl ca-certificates unzip</code></div>
<p>Unzip the project into your Ubuntu home folder. The file <code>install-linux-tools.sh</code> is inside it. From the project folder:</p>
<div class="command"><span class="stepnum">4.</span><code>./install-linux-tools.sh</code></div>
<div class="command"><span class="stepnum">5.</span><code>docker version</code></div>
<h3>C. Ubuntu Linux VM, including an Azure Ubuntu VM</h3>
<p>Use Ubuntu 22.04/24.04 on a <strong>disposable</strong> VM with roughly 4 vCPUs, at least 8 GB RAM and about 30 GB free space. SSH to the VM. Do not expose Docker or Kubernetes API ports to the internet.</p>
<div class="command"><span class="stepnum">1.</span><code>sudo apt update</code></div>
<div class="command"><span class="stepnum">2.</span><code>sudo apt install -y docker.io curl ca-certificates unzip</code></div>
<div class="command"><span class="stepnum">3.</span><code>sudo systemctl enable --now docker</code></div>
<div class="command"><span class="stepnum">4.</span><code>sudo usermod -aG docker "$USER"</code></div>
<div class="command"><span class="stepnum">5.</span><code>newgrp docker</code></div>
<p>Unzip the project and change to its folder, then:</p>
<div class="command"><span class="stepnum">6.</span><code>./install-linux-tools.sh</code></div>
<div class="command"><span class="stepnum">7.</span><code>docker version</code></div>
<p class="small">Cloud VMs can incur charges until deleted. This exercise uses Kind inside Docker on the VM; it does not create Azure AKS or AWS EKS.</p>
<h3>All three computers: create your first Kubernetes cluster</h3>
<p>Keep the terminal <strong>inside the unzipped project folder</strong>. Ensure Docker is running. Start with these four commands, one by one:</p>
<div class="command"><span class="stepnum">1.</span><code>./lab setup</code></div>
<div class="command"><span class="stepnum">2.</span><code>kubectl get nodes</code></div>
<div class="command"><span class="stepnum">3.</span><code>kubectl -n practice get pods</code></div>
<div class="command"><span class="stepnum">4.</span><code>kubectl -n practice get services</code></div>
<p>You should see one control-plane node, two workers, a <strong>Running / Ready</strong> web Pod and a <strong>web</strong> Service. It may take a minute on the first run. The script creates only the cluster named <strong>interview-lab</strong>.</p>
<p><strong>When you complete any Kubernetes question:</strong> type <code>./lab reset</code> to restore the healthy app before starting a different question. For Docker questions, <code>./lab prepare DCK-001</code> (with the ID you want) also restores a healthy baseline.</p>
<h3>Six commands to remember</h3>
<ul><li><strong>docker ps -a</strong>: Which containers stopped or restarted?</li>
<li><strong>docker logs NAME</strong>: What did the application print?</li>
<li><strong>kubectl get pods</strong>: Running, Pending, or CrashLoopBackOff?</li>
<li><strong>kubectl describe pod</strong>: Why is Kubernetes unhappy? Read Events.</li>
<li><strong>kubectl logs</strong>: What error did the process produce?</li>
<li><strong>kubectl rollout status</strong>: Did the repaired release become Ready?</li></ul>
<p class="note"><strong>Safety:</strong> Do not run fault-injection commands against work, customer, AKS, EKS or production clusters. Before every Kubernetes exercise, type <code>kubectl config current-context</code> and confirm it says <code>kind-interview-lab</code>. All exercises except the clearly labeled extra CNI/VM cases are designed for that disposable cluster. A failed command in the "Break" section is often the expected symptom—continue with "Find".</p>
</section>
<h2>Part 2. Docker: Questions 1–10</h2>
<p>Start here if you are new. Complete each question in order. Type <code>./lab prepare DCK-001</code>, then read just that question. The container should be healthy before you break it.</p>
@@DOCKER@@
<h2>Part 3. Kubernetes: Questions 1–50</h2>
<p>When Docker commands feel familiar, practise the Kubernetes questions. Each begins with <code>./lab prepare K8S-001</code> (change the ID), followed by <code>kubectl -n practice get pods</code>. The script rebuilds only the <code>practice</code> namespace; manual commands create the real fault and repair it.</p>
@@KUBERNETES@@
<h2>Last step: what to say in an interview</h2>
<p>Use this short answer for almost every outage: <strong>“I check the failing resource and its events first. Then I check application logs and the network or storage path. I identify the exact root cause, change only what is needed, and verify the Pod and the user-facing service are healthy.”</strong></p>
<p>For each question, write your own five-line note: <strong>Symptoms → Command → Evidence → Root cause → Verification.</strong> Practise without looking at the answer a second time.</p>
<h2>Stop and clean up</h2>
<p>The cluster is intentionally disposable. When you are completely finished:</p>
<div class="command"><span class="stepnum">1.</span><code>./lab reset</code></div>
<div class="command"><span class="stepnum">2.</span><code>./lab cleanup --yes</code></div>
<p>This deletes only the named Kind practice cluster and lab-labeled Docker containers. It does not wipe your other Docker objects.</p>
<p class="small"><strong>Official references:</strong> <a href="https://kind.sigs.k8s.io/docs/user/quick-start/">Kind Quick Start</a>; <a href="https://docs.docker.com/desktop/features/wsl/">Docker + WSL2</a>; <a href="https://kubernetes.io/docs/tasks/debug/">Kubernetes Debugging</a>; <a href="https://docs.tigera.io/calico/latest/getting-started/kubernetes/kind">Calico on Kind (optional)</a>. The guide was built in October 2026; Kubernetes behavior and add-on installation can be version-sensitive.</p>
</main></body></html>'''
html_page=start.replace('@@DOCKER@@',before).replace('@@KUBERNETES@@',after)
(ROOT/'START-HERE.html').write_text(html_page,encoding='utf-8')

text=[]
text.append('SIMPLE DOCKER + KUBERNETES PRACTICE: START HERE\n')
text.append('FIRST: Install Docker and Kind (Mac: Docker Desktop + brew install kind kubectl; Windows: Docker Desktop WSL2 + ./install-linux-tools.sh; Ubuntu VM: Docker Engine + ./install-linux-tools.sh).\n')
text.append('Then type each line in order:\n./lab setup\nkubectl get nodes\nkubectl -n practice get pods\n')
text.append('Every scenario: START HEALTHY -> BREAK -> FIND -> FIX -> VERIFY. Commands are one per line.\n')
for i,s in enumerate(SCENARIOS):
    text.append('\n'+'='*64+f'\nQUESTION {i+1 if i<10 else i-9}. {s["title"]} ({s["id"]})\nWhere: {s["env"]}\n')
    if s['id'] not in ('K8S-024','K8S-042'):
        text.append('1. START HEALTHY\n./lab prepare '+s['id']+'\n')
        text.append('kubectl -n practice get pods\n' if i>=10 else 'docker ps -a\n')
    else:
        text.append('1. OPTIONAL SETUP (read note below; not runnable on ordinary Kind)\n')
    for label,field in [('2. BREAK','breaks'),('3. FIND','finds'),('4. FIX','fixes'),('5. VERIFY','checks')]:
        text.append('\n'+label+'\n'+('\n'.join(s[field]))+'\n')
    text.append('\nEXPECT: '+s['see']+'\nINTERVIEW: '+s['say']+'\n')
    if s['note']:text.append('NOTE: '+s['note']+'\n')
text.append('\nDONE: ./lab reset ; ./lab cleanup --yes\n')
(ROOT/'COMMANDS-ONE-BY-ONE.txt').write_text('\n'.join(text),encoding='utf-8')
(ROOT/'tools'/'scenario-index.json').write_text(json.dumps(SCENARIOS,indent=2),encoding='utf-8')
print('Generated',ROOT/'START-HERE.html',len(html_page),'chars, text',len(''.join(text)),'chars')

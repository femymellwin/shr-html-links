SIMPLE DOCKER + KUBERNETES PRACTICE
===================================

1. OPEN: START-HERE.html    <-- This is the one simple, complete document.

2. INSTALL Docker + kind + kubectl. Mac/Windows/Ubuntu instructions are at the top.

3. TYPE: ./lab setup

4. OPEN Question 1, then type each line in order:
   START HEALTHY -> BREAK -> FIND -> FIX -> VERIFY.

5. TYPE: ./lab reset    before the next Kubernetes question.

6. TYPE: ./lab cleanup --yes    when you are finished with the entire lab.

The guide has 10 Docker and 50 Kubernetes interview practice questions.

For the exact same commands in plain text: COMMANDS-ONE-BY-ONE.txt

NOTE: It is a complete offline practice manual and local app/source package.
Most exercises use disposable Kind. Real DiskPressure and Calico NetworkPolicy
require a separate VM/CNI lab; they are NOT falsely represented as executable
on ordinary Kind. Ingress and HPA have optional online add-on installation.

Live Docker/Kubernetes execution was NOT possible in this build environment.
Run the steps on your own Mac/Windows WSL2/Ubuntu machine to verify behaviors.

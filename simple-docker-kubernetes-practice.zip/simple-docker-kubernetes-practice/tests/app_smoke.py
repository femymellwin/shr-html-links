#!/usr/bin/env python3
"""Starts the real local app without Docker and checks its endpoints."""
from pathlib import Path
import os,subprocess,time,urllib.request,urllib.error,socket,sys
ROOT=Path(__file__).resolve().parent.parent
with socket.socket() as sock:
    sock.bind(('127.0.0.1',0))
    port=sock.getsockname()[1]
env=dict(os.environ, APP_PORT=str(port), APP_BIND='127.0.0.1', APP_MODE='normal')
proc=subprocess.Popen([sys.executable,'-u',str(ROOT/'app'/'app.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
try:
    for _ in range(40):
        try:
            with urllib.request.urlopen(f'http://127.0.0.1:{port}/healthz',timeout=1) as r:
                assert r.status==200
            break
        except (OSError,urllib.error.URLError):
            time.sleep(0.15)
    else:
        raise RuntimeError('App did not become ready')
    for path in ('/readyz','/','/slow'):
        with urllib.request.urlopen(f'http://127.0.0.1:{port}{path}',timeout=2) as r:
            assert r.status==200,(path,r.status)
    print('PASS: real Python HTTP app served healthz, readyz, / and /slow')
finally:
    proc.terminate()
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:proc.kill()

#!/usr/bin/env python3
"""Static, offline checks; does NOT claim a Docker/Kubernetes runtime was tested."""
from pathlib import Path
import json,sys,subprocess,re
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from scenarios import SCENARIOS

errors=[]
assert len(SCENARIOS)==60
ids=[s['id'] for s in SCENARIOS]
assert ids==[f'DCK-{i:03d}' for i in range(1,11)]+[f'K8S-{i:03d}' for i in range(1,51)]
for s in SCENARIOS:
    assert s['see'] and s['say']
    for phase in ('breaks','finds','fixes','checks'):
        assert s[phase],(s['id'],phase)
        for c in s[phase]:
            if c.startswith('#'): continue
            p=subprocess.run(['bash','-n','-c',c],capture_output=True,text=True)
            if p.returncode:
                errors.append(f'{s["id"]}/{phase}: bad shell command: {c}: {p.stderr}')
            if 'patch ' in c and "-p '" in c:
                try:json.loads(c.split("-p '",1)[1].split("'",1)[0])
                except Exception as e:errors.append(f'{s["id"]}/{phase}: bad JSON patch: {e}')
            for ref in re.findall(r'-f (manifests/[a-zA-Z0-9._/-]+\.yaml)',c):
                if not (ROOT/ref).is_file():errors.append(f'{s["id"]}: missing {ref}')
for script in ('lab','install-linux-tools.sh'):
    r=subprocess.run(['bash','-n',str(ROOT/script)],capture_output=True,text=True)
    if r.returncode:errors.append(script+': '+r.stderr)
try:
    import yaml
    for file in sorted((ROOT/'manifests').glob('*.yaml')):
        with file.open(encoding='utf-8') as f:
            for obj in yaml.safe_load_all(f):
                if not isinstance(obj,dict) or not obj.get('kind') or not obj.get('apiVersion'):
                    errors.append('Incomplete YAML object: '+str(file))
except ImportError:
    print('PyYAML missing; skipping optional YAML parse')
content=(ROOT/'START-HERE.html').read_text()
for sid in ids:
    if f'id="{sid}"' not in content: errors.append('Missing HTML section '+sid)
if content.count('<article class="scenario"') != 60:errors.append('Expected 60 HTML scenario sections')
if content.count('</article>') != 60:errors.append('Unclosed scenario sections')
if errors:
    print('\n'.join(errors))
    raise SystemExit(f'FAILED ({len(errors)} issues)')
print('PASS: 60 ordered scenario IDs; shell syntax; JSON patches; referenced YAMLs; YAML object structure; HTML completeness')
print('NOTE: Docker/Kind live execution NOT performed by this static validator.')

#!/usr/bin/env bash
# Installs kubectl and kind on x86_64/aarch64 Ubuntu or WSL2. Docker is separate.
set -euo pipefail
command -v curl >/dev/null || { echo 'Install curl first: sudo apt update && sudo apt install -y curl'; exit 1; }
case "$(uname -m)" in x86_64) ARCH=amd64;; aarch64|arm64) ARCH=arm64;; *) echo 'Unsupported CPU: '"$(uname -m)"; exit 1;; esac
KVER="$(curl -fsSL https://dl.k8s.io/release/stable.txt)"
KIND_VERSION='v0.33.0'
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
printf 'Downloading kubectl %s for linux/%s\n' "$KVER" "$ARCH"
curl -fsSL -o "$TMP/kubectl" "https://dl.k8s.io/release/${KVER}/bin/linux/${ARCH}/kubectl"
curl -fsSL -o "$TMP/kubectl.sha256" "https://dl.k8s.io/release/${KVER}/bin/linux/${ARCH}/kubectl.sha256"
echo "$(cat "$TMP/kubectl.sha256")  $TMP/kubectl" | sha256sum -c -
printf 'Downloading kind %s for linux/%s\n' "$KIND_VERSION" "$ARCH"
curl -fsSL -o "$TMP/kind" "https://kind.sigs.k8s.io/dl/${KIND_VERSION}/kind-linux-${ARCH}"
sudo install -m 0755 "$TMP/kubectl" /usr/local/bin/kubectl
sudo install -m 0755 "$TMP/kind" /usr/local/bin/kind
kubectl version --client
kind version

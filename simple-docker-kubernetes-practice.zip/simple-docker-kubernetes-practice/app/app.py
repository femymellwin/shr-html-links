#!/usr/bin/env python3
"""Small intentionally breakable HTTP server; Python standard library only."""
import os
import sys
import time
import signal
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MODE = os.environ.get('APP_MODE', 'normal')
PORT = int(os.environ.get('APP_PORT', '8080'))
HOST = os.environ.get('APP_BIND', '0.0.0.0')
MESSAGE = os.environ.get('APP_MESSAGE', 'hello from the practice app')

if MODE in ('crash', 'bad-config'):
    sys.exit('LAB: intentional startup failure (APP_MODE=' + MODE + ')')
if MODE == 'exit0':
    print('LAB: process completed normally and exited', flush=True)
    sys.exit(0)
if MODE == 'allocate':
    total = int(os.environ.get('ALLOC_MB', '200'))
    blocks = []
    for i in range(total):
        b = bytearray(1024 * 1024)
        b[0] = 1
        blocks.append(b)
    print('Allocated', total, 'MiB', flush=True)
if MODE == 'write':
    with open('/data/ready.txt', 'w', encoding='utf-8') as f:
        f.write('saved by practice app\n')
if MODE == 'ignore-term':
    signal.signal(signal.SIGTERM, signal.SIG_IGN)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/healthz'):
            status = 503 if MODE == 'unhealthy' else 200
            text = 'unhealthy' if status != 200 else 'ok'
        elif self.path.startswith('/readyz'):
            status = 503 if MODE == 'unready' else 200
            text = 'not ready' if status != 200 else 'ready'
        elif self.path.startswith('/slow'):
            time.sleep(8 if MODE == 'slow' else 0)
            status, text = 200, 'slow response'
        elif self.path.startswith('/external'):
            url = os.environ.get('EXTERNAL_URL', 'http://backend.practice.svc.cluster.local/healthz')
            try:
                with urllib.request.urlopen(url, timeout=2) as r:
                    status, text = 200, 'dependency: ' + r.read(80).decode('utf-8', errors='replace')
            except Exception as exc:
                status, text = 502, 'dependency unavailable: ' + str(exc)
        elif self.path.startswith('/value'):
            try:
                with open('/data/ready.txt', encoding='utf-8') as f:
                    status, text = 200, f.read()
            except OSError as exc:
                status, text = 500, str(exc)
        elif MODE == 'fail-http':
            status, text = 500, 'LAB: application HTTP error'
        else:
            status, text = 200, MESSAGE + '\n'
        data = text.encode('utf-8', errors='replace')
        try:
            self.send_response(status)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except BrokenPipeError:
            pass
        print('HTTP', self.path, status, flush=True)


if MODE == 'crash-after':
    import threading
    threading.Thread(target=lambda: (time.sleep(5), os._exit(4)), daemon=True).start()

print('LAB: listening on', HOST, PORT, 'mode', MODE, flush=True)
ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()

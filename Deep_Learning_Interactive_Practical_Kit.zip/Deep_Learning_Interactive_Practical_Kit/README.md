# Deep Learning Interactive Practical Kit

## Open the student guide

Open `index.html` in a browser (Chrome, Edge, Firefox, Safari). It is self-contained,
works without a web server, and includes all four experimental walkthroughs and Python code.
Use `Copy complete program`, `Copy cell`, or `Download .py` as needed.

## Files included

- `index.html`: full offline HTML walkthrough, source figures, copy controls, viva, checks.
- `scripts/`: 4 independent Python source files.
- `notebooks/`: 4 Jupyter notebooks with the experiments split into cells.
- `source/Original_Lab_Manual.pdf`: user's original 26-page lab manual.
- `requirements.txt`: Python packages when not already installed in the laboratory.
- `data/README.txt`: dataset instructions; no external dataset is misrepresented as provided.

## Run in Python

From this project directory, if the lab environment is not already configured:

```sh
python -m pip install -r requirements.txt
```

Then, for example:

```sh
python scripts/experiment_01_perceptron.py
python scripts/experiment_02_xor_dnn.py
python scripts/experiment_03_mnist.py
python scripts/experiment_04_character_cnn.py
```

In Jupyter, open the corresponding notebook and run cells in order. The notebook
can run from this project directory. For Experiment 04, the lab-provided dataset
is required. Open `index.html#exp4` for class-scope caveats and file paths.

## Accuracy / data warning

The original manual has an inconsistency in its CNN labels: its written objective
is A-Z, while sample CSV and model summary show 36 mixed classes. The checked
script defaults to letter-only and rejects unexpected digits unless you explicitly
change `LABEL_MODE = "all"` for a mixed-class assignment confirmed by the lab.
Do not treat the source's reported percentages as newly measured results.

The original manual dataset URL was previously checked and returned HTTP 404.
Obtain the actual character dataset from the laboratory.

## Offline controls

The guide stores checkbox progress in local browser storage when allowed.
Copy uses clipboard access or a local fallback for `file://` pages.

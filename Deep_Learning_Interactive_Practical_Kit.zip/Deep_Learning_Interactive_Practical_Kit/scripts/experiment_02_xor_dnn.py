"""Experiment 02: source 2-2-1 XOR model and its manual initialization."""
# %% Part A - model and manual weights
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.optimizers import Adam

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype="float32")
y = np.array([[0], [1], [1], [0]], dtype="float32")
model = Sequential([
    Input(shape=(2,)),
    Dense(2, activation="sigmoid", name="hidden"),
    Dense(1, activation="sigmoid", name="output"),
])
model.compile(optimizer=Adam(learning_rate=1.0),
              loss="binary_crossentropy", metrics=["accuracy"])

W1 = np.array([[2.524, -5.875], [-2.715, 5.026]])
b1 = np.array([-1.429, -3.095])
W2 = np.array([[1.531], [3.240]])
b2 = np.array([-1.099])
model.get_layer("hidden").set_weights([W1, b1])
model.get_layer("output").set_weights([W2, b2])

print("Initial weights and biases:")
for layer in model.layers:
    print(layer.name, layer.get_weights())
initial_preds = model.predict(X, verbose=0).ravel()
print("Initial probabilities:", np.round(initial_preds, 4))
print("Initial classes:", (initial_preds > 0.5).astype(int))
# The manual checks the stopping condition AFTER each training epoch.

# %% Part B - callback, training, evaluation and plots
class EpochLogger(tf.keras.callbacks.Callback):
    def on_epoch_end(self, epoch, logs=None):
        probs = self.model.predict(X, verbose=0).ravel()
        classes = (probs > 0.5).astype(int)
        print(f"\nEpoch {epoch + 1}")
        for row, prob, cls in zip(X, probs, classes):
            print(f"Input={row}, output={prob:.4f}, class={cls}")
        for layer in self.model.layers:
            w, b = layer.get_weights()
            print(layer.name, "weights:", np.round(w, 3))
            print("biases:", np.round(b, 3))
        if np.array_equal(classes, y.ravel().astype(int)):
            print("All predictions correct. Stopping early.")
            self.model.stop_training = True

history = model.fit(
    X, y, epochs=100, batch_size=4, verbose=0,
    validation_data=(X, y), callbacks=[EpochLogger()]
)
final_probs = model.predict(X, verbose=0).ravel()
print("\nFinal XOR predictions:")
for row, prob in zip(X, final_probs):
    print(f"Input={row}, output={prob:.4f}, class={int(prob > 0.5)}")
loss, accuracy = model.evaluate(X, y, verbose=0)
print(f"Final truth-table accuracy: {accuracy:.4f}; loss: {loss:.4f}")

# Separate figures contain the same curves as the manual.
for metric, title in [("accuracy", "Accuracy"), ("loss", "Loss")]:
    plt.figure(figsize=(6, 4))
    epoch_axis = np.arange(1, len(history.history[metric]) + 1)
    plt.plot(epoch_axis, history.history[metric], label="Train")
    plt.plot(epoch_axis, history.history["val_" + metric],
             linestyle="--", label="Validation (same four rows)")
    plt.xlabel("Epoch")
    plt.ylabel(title)
    plt.title(f"XOR - {title} over epochs")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

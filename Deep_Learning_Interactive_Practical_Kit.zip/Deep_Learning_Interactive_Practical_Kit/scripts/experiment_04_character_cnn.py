"""Experiment 04: source CNN with explicit, checked label handling.
Run from the project folder. Obtain the real dataset from the laboratory.
The supplied PDF does not contain the image files or CSV as attachments.
"""
# %% Part A - paths, CSV checks and class mapping
from pathlib import Path
import string
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import (
    Input, Conv2D, MaxPooling2D, Flatten, Dense, Dropout
)
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical

# CHANGE ROOT to the folder containing english.csv and Img/.
ROOT = Path("data/CharacterR")
CSV_FILE = ROOT / "english.csv"
LABEL_MODE = "letters"  # "all" ONLY for an approved mixed-label task.
IMG_SIZE = 28
if not CSV_FILE.is_file():
    raise FileNotFoundError(f"Cannot find {CSV_FILE.resolve()}")
df = pd.read_csv(CSV_FILE, dtype=str)
if not {"image", "label"}.issubset(df.columns):
    raise ValueError("CSV must contain image and label columns.")
if df.empty or df[["image", "label"]].isna().any().any():
    raise ValueError("CSV is empty or has missing image/label values.")
df["label"] = df["label"].str.strip().str.upper()
labels = df["label"].to_numpy()
print(df.head())
print("Unique labels:", sorted(set(labels)))
if any(len(label) != 1 for label in labels):
    raise ValueError("Every label must be one character.")
if LABEL_MODE == "letters":
    class_names = list(string.ascii_uppercase)
    bad = sorted(set(labels) - set(class_names))
    if bad:
        raise ValueError(f"Non A-Z labels: {bad}. Confirm task scope.")
elif LABEL_MODE == "all":
    class_names = sorted(set(labels))
else:
    raise ValueError("LABEL_MODE must be 'letters' or 'all'.")
class_to_id = {label: i for i, label in enumerate(class_names)}
num_classes = len(class_names)
print("Class mapping:", class_to_id)

# %% Part B - images, normalization, split and inspection
images = []
for filename in df["image"]:
    path = ROOT / filename.replace("\\", "/")
    if not path.is_file():
        raise FileNotFoundError(f"Missing image: {path}")
    with Image.open(path) as img:
        gray = img.convert("L").resize((IMG_SIZE, IMG_SIZE))
        images.append(np.asarray(gray, dtype="float32") / 255.0)
X = np.asarray(images, dtype="float32")[..., np.newaxis]
y_ids = np.array([class_to_id[label] for label in labels])
y = to_categorical(y_ids, num_classes)
assert X.shape[1:] == (28, 28, 1)
assert y.shape[1] == num_classes
print("Input shape:", X.shape, "Label shape:", y.shape)
print("Pixel range:", X.min(), X.max())
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print("Training set:", X_train.shape, "Test set:", X_test.shape)

plt.figure(figsize=(10, 4))
for i in range(min(10, len(X_train))):
    plt.subplot(2, 5, i + 1)
    label = class_names[int(np.argmax(y_train[i]))]
    plt.imshow(X_train[i, :, :, 0], cmap="gray")
    plt.title(f"Label: {label}")
    plt.axis("off")
plt.suptitle("Sample Training Images")
plt.tight_layout()
plt.show()

# %% Part C - source CNN, training and test evaluation
model = Sequential([
    Input(shape=(IMG_SIZE, IMG_SIZE, 1)),
    Conv2D(32, (3, 3), activation="relu"),
    MaxPooling2D((2, 2)),
    Conv2D(64, (3, 3), activation="relu"),
    MaxPooling2D((2, 2)),
    Flatten(),
    Dense(128, activation="relu"),
    Dropout(0.5),
    Dense(num_classes, activation="softmax"),
])
model.compile(optimizer=Adam(), loss="categorical_crossentropy",
              metrics=["accuracy"])
model.summary()
history = model.fit(
    X_train, y_train, epochs=10, batch_size=64,
    validation_split=0.2, verbose=1
)
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Test Accuracy: {test_acc * 100:.2f}%")
print(f"Test Loss: {test_loss:.4f}")

for metric, title in [("accuracy", "Accuracy"), ("loss", "Loss")]:
    plt.figure(figsize=(6, 4))
    epochs = np.arange(1, len(history.history[metric]) + 1)
    plt.plot(epochs, history.history[metric], label="Training")
    plt.plot(epochs, history.history["val_" + metric],
             linestyle="--", label="Validation")
    plt.xlabel("Epoch")
    plt.ylabel(title)
    plt.title(f"Character CNN - {title}")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# %% Part D - decode predictions with the SAME class mapping
probs = model.predict(X_test[:10], verbose=0)
pred_ids = np.argmax(probs, axis=1)
true_ids = np.argmax(y_test[:10], axis=1)
plt.figure(figsize=(10, 4))
for i in range(len(probs)):
    plt.subplot(2, 5, i + 1)
    predicted = class_names[int(pred_ids[i])]
    actual = class_names[int(true_ids[i])]
    print(f"Sample {i}: predicted={predicted}, actual={actual}")
    plt.imshow(X_test[i, :, :, 0], cmap="gray")
    plt.title(f"Pred: {predicted}, True: {actual}")
    plt.axis("off")
plt.tight_layout()
plt.show()

"""Experiment 01: AND perceptron; settings follow the supplied manual."""
# %% Part A - data and training
import numpy as np
import matplotlib.pyplot as plt

X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
T = np.array([0, 0, 0, 1])
weights = np.array([0.3, -0.1], dtype=float)
bias = 0.2
alpha = 0.1
epochs = 10

for epoch in range(epochs):
    errors = 0
    print(f"\nEpoch {epoch + 1}")
    for x_i, target in zip(X, T):
        z = np.dot(weights, x_i) + bias
        output = int(z >= 0)
        error = int(target) - output
        if error != 0:
            weights += alpha * error * x_i
            bias += alpha * error
            errors += 1
        print(f"X={x_i}, target={target}, output={output}, "
              f"weights={weights}, bias={bias}")
    if errors == 0:
        print("Training converged. Stopping early.")
        break

# %% Part B - verification and boundary
predictions = (X @ weights + bias >= 0).astype(int)
print("\nFinal weights:", weights, "Final bias:", bias)
for x_i, prediction in zip(X, predictions):
    print(f"X={x_i}, prediction={prediction}")
print("All AND outputs correct:", np.array_equal(predictions, T))

plt.figure(figsize=(6, 5))
for target in (0, 1):
    points = X[T == target]
    plt.scatter(points[:, 0], points[:, 1],
                label=f"Target {target}")
# Added guard: do not divide by a zero second weight.
if not np.isclose(weights[1], 0):
    x1 = np.array([-0.1, 1.1])
    x2 = -(weights[0] * x1 + bias) / weights[1]
    plt.plot(x1, x2, label="Decision boundary")
elif not np.isclose(weights[0], 0):
    plt.axvline(-bias / weights[0], label="Decision boundary")
else:
    print("No nontrivial boundary: both weights are zero.")
plt.xlabel("x1")
plt.ylabel("x2")
plt.title("Perceptron Decision Boundary - AND")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

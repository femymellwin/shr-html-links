"""Experiment 03: MNIST feedforward network; source training settings."""
# %% Part A - load, inspect and preprocess
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Dense, Flatten
from tensorflow.keras.utils import to_categorical

# First execution downloads MNIST unless it is already cached.
(X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
print("Raw shapes:", X_train.shape, y_train.shape,
      X_test.shape, y_test.shape)
unique, counts = np.unique(y_train, return_counts=True)
for digit, count in zip(unique, counts):
    print(f"Digit {digit}: {count} samples")

plt.figure(figsize=(10, 10))
for i in range(50):
    plt.subplot(5, 10, i + 1)
    plt.imshow(X_train[i], cmap="gray")
    plt.title(str(y_train[i]), fontsize=8)
    plt.axis("off")
plt.suptitle("50 Sample Digits from Training Set")
plt.tight_layout()
plt.show()

X_train = X_train.astype("float32") / 255.0
X_test = X_test.astype("float32") / 255.0
y_train_cat = to_categorical(y_train, 10)
y_test_cat = to_categorical(y_test, 10)
assert X_train.shape[1:] == (28, 28)
assert y_train_cat.shape[1] == 10
print("Normalized range:", X_train.min(), X_train.max())

# %% Part B - model, training and independent test
model = Sequential([
    Input(shape=(28, 28)),
    Flatten(),
    Dense(128, activation="relu"),
    Dense(10, activation="softmax"),
])
model.compile(optimizer="adam", loss="categorical_crossentropy",
              metrics=["accuracy"])
model.summary()
history = model.fit(
    X_train, y_train_cat, epochs=10, batch_size=64,
    validation_split=0.2, verbose=1
)
test_loss, test_acc = model.evaluate(X_test, y_test_cat, verbose=0)
print(f"Test Accuracy: {test_acc:.4f}, Test Loss: {test_loss:.4f}")

for metric, title in [("accuracy", "Accuracy"), ("loss", "Loss")]:
    plt.figure(figsize=(6, 4))
    epochs = np.arange(1, len(history.history[metric]) + 1)
    plt.plot(epochs, history.history[metric], label="Training")
    plt.plot(epochs, history.history["val_" + metric],
             linestyle="--", label="Validation")
    plt.xlabel("Epoch")
    plt.ylabel(title)
    plt.title(f"MNIST - {title} over epochs")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

# %% Part C - predict and display ten test images
predictions = model.predict(X_test[:10], verbose=0)
predicted_classes = np.argmax(predictions, axis=1)
print("Predicted digits:", predicted_classes)
print("Actual digits:   ", y_test[:10])
plt.figure(figsize=(10, 4))
for i in range(10):
    plt.subplot(2, 5, i + 1)
    plt.imshow(X_test[i], cmap="gray")
    plt.title(f"Pred: {predicted_classes[i]}, True: {y_test[i]}")
    plt.axis("off")
plt.tight_layout()
plt.show()

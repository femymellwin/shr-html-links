Experiment 04: Place the real lab dataset in data/CharacterR/ so that english.csv and Img/ exist.
Experiment 03: MNIST loads through Keras and may require one initial download.
